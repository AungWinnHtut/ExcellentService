-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 27, 2015 at 07:24 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `esdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(25) DEFAULT NULL,
  `user_email` varchar(40) DEFAULT NULL,
  `user_password` varchar(40) NOT NULL,
  `user_phoneno` varchar(20) DEFAULT NULL,
  `user_dob` date NOT NULL,
  `user_profession` varchar(40) DEFAULT NULL,
  `user_city` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=50 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_name`, `user_email`, `user_password`, `user_phoneno`, `user_dob`, `user_profession`, `user_city`) VALUES
(1, 'aung', 'aung@gmail.com', '12345', '095506082', '1978-02-19', 'student', 'yangong'),
(2, 'koko', 'koko@gmail.com', '11111', '095506083', '1888-12-19', 'student', 'mandalay'),
(44, 'yezaw', 'yezaw@gmail.com', '12345', '56678888', '2015-07-06', 'doctor', 'ygn'),
(46, 'yezawmyint', 'yezaw@gmail.com', '12345', '0933327917', '1983-07-06', 'student', 'pyinoolwin'),
(47, 'soethant', 'soe@gmail.com', '123456', '2058054', '2015-03-20', 'dr', 'maymyo'),
(48, 'agag', 'ag@gmail.com', '12345', '098766544', '2015-07-07', 'dr', 'ygn'),
(49, 'phoneko', 'phoneko@gmail.com', '12345', '557788', '2015-06-07', 'doctor', 'ygn');
